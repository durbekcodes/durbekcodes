def cli():
    from app import misc

    misc.setup()
