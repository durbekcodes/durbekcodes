from . import new_music, paginate, start_private, liked, liked_paginate, top, adminstrator, search_mp3_inline, \
    search_mp3
