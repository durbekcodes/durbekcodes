# vkm_bot

# Foydalanish
__Bot buyruqlari__:

/start - **Botni ishga tushirish**<br>
/stat - **Statistikani ko'rish**<br>
/top - **Ko'p tinglangan musiqalar**<br>
/my - **Playlist**<br><br>

Murojaat uchun: [t.me/TILON](t.me/TILON)
